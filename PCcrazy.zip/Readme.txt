=============
_PCcrazy.exe_
=============

Made By Minhgotuknight19

Created: April 18 2024
Made In C++
Dont RUN your PC

This Is Non-Safety Run Malware

Credits To GetMBR For Hue Functions

-------------------------------------------------------
The PC Is Crazy Funny
Name Means :
PC Funny

--------
--------
--------

-------------------------------------------------------

scroll down :)



scroll down :\





scroll down :/




scroll down :|









Hi I am Wynn and Yedb0y33k